<!DOCTYPE html>
<html>

<head>

<title>FitTrack Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


<style>

body{

background:#0d0d0d;
color:white;

}


.card-box{

background:#181818;

border:1px solid #ffc107;

border-radius:20px;

padding:25px;

height:100%;

}


.title{

color:#ffc107;

font-weight:bold;

}


</style>


</head>


<body>


<div class="container mt-5">


<h1 class="text-warning text-center mb-5">
<div class="text-end mb-4">
    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" class="btn btn-danger">
            Logout
        </button>
    </form>
</div>

Welcome {{Auth::user()->name}} 💪

</h1>



<div class="row">


<div class="col-md-6 mb-4">


<div class="card-box">


<h3 class="title">

Active Membership

</h3>


@if($membership)


<h4>
{{$membership->plan->plan_name}}
</h4>


<p>

Start :
{{$membership->start_date}}

</p>


<p>

Expiry :
{{$membership->end_date}}

</p>


<span class="badge bg-success">

{{$membership->status}}

</span>


@else


<p>
No Active Membership
</p>


@endif


</div>


</div>





<div class="col-md-6 mb-4">


<div class="card-box">


<h3 class="title">

Workout Plans

</h3>


@foreach($workouts as $workout)


<p>

🏋 {{$workout->workout_name}}

</p>


@endforeach


</div>


</div>



</div>


</div>


</body>

</html>