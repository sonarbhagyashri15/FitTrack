<!DOCTYPE html>
<html>

<head>

<title>Workout Plans | FitTrack</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


<style>

body{

background:#0d0d0d;

color:white;

}


.workout-card{

background:#181818;

border:1px solid #ffc107;

border-radius:20px;

padding:30px;

height:100%;

transition:.3s;

}


.workout-card:hover{

transform:translateY(-10px);

box-shadow:0 0 25px #ffc107;

}


.title{

color:#ffc107;

font-size:28px;

font-weight:bold;

}

</style>


</head>


<body>


<div class="container mt-5">


<h1 class="text-warning text-center mb-5">

🏋 Workout Plans

</h1>


<div class="text-center mb-4">

<a href="{{route('workout-plans.create')}}"
class="btn btn-warning">

+ Add Workout

</a>

</div>



<div class="row">


@foreach($workouts as $workout)


<div class="col-md-4 mb-4">


<div class="workout-card text-center">


<h3 class="title">

{{$workout->workout_name}}

</h3>


<h5>

{{$workout->category}}

</h5>


<p>

{{$workout->duration}}

</p>


<p>

{{$workout->description}}

</p>
<br>

<a href="{{ route('workout-plans.edit',$workout->id) }}"
class="btn btn-primary">

Edit

</a>


<form action="{{ route('workout-plans.destroy',$workout->id) }}"
method="POST"
style="display:inline">


@csrf

@method('DELETE')


<button class="btn btn-danger"
onclick="return confirm('Delete Workout?')">

Delete

</button>


</form>


</div>


</div>


@endforeach


</div>


</div>


</body>

</html>