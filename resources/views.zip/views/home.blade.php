<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>FitTrack | Gym Membership Portal</title>

    <!-- Bootstrap -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->

    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, Helvetica, sans-serif;
        }

        body{

            background:#111;
            color:white;

        }

        /* NAVBAR */

        .navbar{

            background:rgba(0,0,0,.75);
            backdrop-filter:blur(8px);

        }

        .navbar-brand{

            font-size:30px;
            color:#ff9800 !important;
            font-weight:bold;

        }

        .nav-link{

            color:white !important;
            margin-left:18px;
            transition:.4s;

        }

        .nav-link:hover{

            color:#ff9800 !important;

        }

        /* HERO */

        .hero{

            height:100vh;

            background:
            linear-gradient(rgba(0,0,0,.70),
            rgba(0,0,0,.70)),
            url("https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1600&q=80");

            background-size:cover;
            background-position:center;

            display:flex;
            justify-content:center;
            align-items:center;
            text-align:center;

        }

        .hero h1{

            font-size:70px;
            font-weight:bold;

        }

        .hero span{

            color:#ff9800;

        }

        .hero p{

            font-size:22px;
            margin-top:20px;
            margin-bottom:35px;

        }

        .btn-orange{

            background:#ff9800;
            color:white;
            padding:14px 35px;
            border:none;
            border-radius:50px;
            font-size:18px;
            transition:.4s;

        }

        .btn-orange:hover{

            background:white;
            color:#ff9800;

        }

        .btn-outline-light{

            padding:14px 35px;
            border-radius:50px;
            margin-left:10px;

        }

    </style>

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar navbar-expand-lg fixed-top">

<div class="container">

<a class="navbar-brand" href="#">
💪 FitTrack
</a>

<button class="navbar-toggler bg-light"
data-bs-toggle="collapse"
data-bs-target="#menu">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse"
id="menu">

<ul class="navbar-nav ms-auto">

<li class="nav-item">

<a class="nav-link" href="#">Home</a>

</li>

<li class="nav-item">

<a class="nav-link" href="#">About</a>

</li>

<li class="nav-item">

<a class="nav-link" href="#">Membership</a>

</li>

<li class="nav-item">

<a class="nav-link" href="#">Workout</a>

</li>

<li class="nav-item">

<a class="nav-link" href="#">Contact</a>

</li>

<li class="nav-item">

<a href="{{ route('login') }}"
class="btn btn-outline-light ms-3">

Login

</a>

</li>

<li class="nav-item">

<a href="{{ route('register') }}"
class="btn btn-orange ms-2">

Register

</a>

</li>

</ul>

</div>

</div>

</nav>

<!-- HERO -->

<section class="hero">

<div class="container">

<h1>

TRANSFORM

<span>

YOUR BODY

</span>

</h1>

<p>

Join FitTrack and achieve your fitness goals with expert trainers,
modern equipment and personalized workout plans.

</p>

<a href="{{ route('register') }}"
class="btn btn-orange">

Join Now

</a>

<a href="#plans"
class="btn btn-outline-light">

Explore Plans

</a>

</div>

</section>
<!-- WHY CHOOSE FITTRACK -->

<section class="py-5 bg-dark">

    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold text-warning">Why Choose FitTrack?</h2>
            <p class="text-light">
                Everything you need to achieve your fitness goals.
            </p>
        </div>

        <div class="row g-4">

            <div class="col-md-3">
                <div class="card bg-black text-white border-warning shadow-lg h-100">
                    <div class="card-body text-center">
                        <h1>🏋️</h1>
                        <h4>Modern Equipment</h4>
                        <p>Latest machines and world-class gym equipment.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-black text-white border-warning shadow-lg h-100">
                    <div class="card-body text-center">
                        <h1>👨‍🏫</h1>
                        <h4>Expert Trainers</h4>
                        <p>Certified trainers to guide your transformation.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-black text-white border-warning shadow-lg h-100">
                    <div class="card-body text-center">
                        <h1>🥗</h1>
                        <h4>Diet Plans</h4>
                        <p>Personalized nutrition plans for every member.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-black text-white border-warning shadow-lg h-100">
                    <div class="card-body text-center">
                        <h1>📅</h1>
                        <h4>Flexible Timing</h4>
                        <p>Morning and evening batches available.</p>
                    </div>
                </div>
            </div>

        </div>

    </div>

</section>

<!-- MEMBERSHIP PLANS -->

<div class="row">

@foreach($plans as $plan)

<div class="col-md-4 mb-4">

<div class="card shadow p-4">

<h3>
{{ $plan->plan_name }}
</h3>

<h2>
₹{{ $plan->price }}
</h2>

<p>
{{ $plan->duration }}
</p>

<p>
{{ $plan->description }}
</p>

</div>

</div>

@endforeach

</div>
<!-- WORKOUT CATEGORIES -->

<section class="py-5 bg-dark">

    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold text-warning">Workout Categories</h2>
            <p class="text-light">Choose your favorite workout style.</p>
        </div>

        <div class="row g-4">

            <div class="col-md-3">
                <div class="card bg-black border-warning text-white text-center shadow-lg h-100">
                    <div class="card-body">
                        <h1>🏃</h1>
                        <h4>Cardio</h4>
                        <p>Improve stamina and burn calories effectively.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-black border-warning text-white text-center shadow-lg h-100">
                    <div class="card-body">
                        <h1>🏋️</h1>
                        <h4>Strength</h4>
                        <p>Build muscles with professional training plans.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-black border-warning text-white text-center shadow-lg h-100">
                    <div class="card-body">
                        <h1>🧘</h1>
                        <h4>Yoga</h4>
                        <p>Increase flexibility and reduce stress naturally.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card bg-black border-warning text-white text-center shadow-lg h-100">
                    <div class="card-body">
                        <h1>🔥</h1>
                        <h4>CrossFit</h4>
                        <p>High-intensity workouts for maximum performance.</p>
                    </div>
                </div>
            </div>

        </div>

    </div>

</section>



                

<!-- ================= CONTACT ================= -->

<section class="py-5 bg-dark text-white">

<div class="container">

<div class="row">

<div class="col-md-6">

<h2 class="text-warning">

Contact Us

</h2>

<p>

📍 Nashik, Maharashtra

</p>

<p>

📞 +91 9876543210

</p>

<p>

✉ fittrack@gmail.com

</p>

</div>




</div>

</div>

</section>

<!-- ================= FOOTER ================= -->

<footer class="bg-black text-white text-center p-4">

<h4 class="text-warning">

💪 FitTrack

</h4>

<p>

Gym Membership & Workout Plan Management Portal

</p>

<hr>

<p>

© 2026 FitTrack | All Rights Reserved

</p>

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>