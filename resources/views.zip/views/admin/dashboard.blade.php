<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard | FitTrack</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,Helvetica,sans-serif;
}

body{
background:#0d1117;
color:white;
overflow-x:hidden;
}

.sidebar{

position:fixed;

left:0;

top:0;

width:260px;

height:100vh;

background:#111827;

padding:30px 20px;

border-right:2px solid #ff9800;

}

.logo{

font-size:30px;

font-weight:bold;

color:#ff9800;

text-align:center;

margin-bottom:40px;

}

.sidebar a{

display:block;

padding:15px;

margin-bottom:12px;

border-radius:10px;

text-decoration:none;

color:white;

transition:.3s;

font-size:17px;

}

.sidebar a:hover{

background:#ff9800;

color:black;

}

.main{

margin-left:260px;

padding:35px;

}

.header{

display:flex;

justify-content:space-between;

align-items:center;

margin-bottom:40px;

}

.header h2{

font-weight:bold;

}

.card-box{

background:#1f2937;

border:2px solid #ff9800;

border-radius:18px;

padding:25px;

transition:.3s;

height:100%;

}

.card-box:hover{

transform:translateY(-8px);

box-shadow:0 0 20px rgba(255,152,0,.4);

}

.count{

font-size:42px;

font-weight:bold;

color:#ff9800;

}

.title{

font-size:18px;

margin-top:8px;

}

.btn-orange{

background:#ff9800;

color:white;

font-weight:bold;

border-radius:30px;

padding:10px 25px;

}

.btn-orange:hover{

background:white;

color:#ff9800;

}

</style>

</head>

<body>

<div class="sidebar">

<div class="logo">

💪 FitTrack

</div>

<a href="{{ route('admin.dashboard') }}">
<i class="bi bi-speedometer2"></i>
 Dashboard
</a>

<a href="{{ route('membership-plans.index') }}">
<i class="bi bi-credit-card"></i>
 Membership Plans
</a>

<a href="{{ route('workout-plans.index') }}">
<i class="bi bi-activity"></i>
 Workout Plans
</a>

<a href="{{ route('workout-videos.index') }}">
<i class="bi bi-camera-video"></i>
 Workout Videos
</a>

<a href="{{ route('progress.index') }}">
<i class="bi bi-graph-up-arrow"></i>
 Progress
</a>

<a href="{{ route('dashboard') }}">
<i class="bi bi-house"></i>
 User Dashboard
</a>

<form action="{{ route('logout') }}" method="POST" class="mt-4">

@csrf

<button class="btn btn-danger w-100">

Logout

</button>

</form>

</div>

<div class="main">

<div class="header">

<div>

<h2>

Admin Dashboard

</h2>

<p class="text-secondary">

Welcome Admin 👋

</p>

</div>

<a href="{{ route('home') }}"
class="btn btn-orange">

Visit Website

</a>

</div>

<div class="row">
<!-- Total Users -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-people-fill text-warning" style="font-size:55px;"></i>

        <div class="count">

            {{ $totalUsers }}

        </div>

        <div class="title">

            Total Users

        </div>

    </div>

</div>

<!-- Membership Plans -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-credit-card-fill text-warning" style="font-size:55px;"></i>

        <div class="count">

            {{ $totalPlans }}

        </div>

        <div class="title">

            Membership Plans

        </div>

    </div>

</div>

<!-- Total Memberships -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-person-vcard-fill text-warning" style="font-size:55px;"></i>

        <div class="count">

            {{ $totalMemberships }}

        </div>

        <div class="title">

            Purchased Memberships

        </div>

    </div>

</div>

<!-- Active Memberships -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-award-fill text-success" style="font-size:55px;"></i>

        <div class="count text-success">

            {{ $activeMemberships }}

        </div>

        <div class="title">

            Active Memberships

        </div>

    </div>

</div>

<!-- Workout Plans -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-activity text-info" style="font-size:55px;"></i>

        <div class="count text-info">

            {{ $totalWorkoutPlans }}

        </div>

        <div class="title">

            Workout Plans

        </div>

    </div>

</div>

<!-- Workout Videos -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-camera-video-fill text-danger" style="font-size:55px;"></i>

        <div class="count text-danger">

            {{ $totalWorkoutVideos }}

        </div>

        <div class="title">

            Workout Videos

        </div>

    </div>

</div>

<!-- Progress Records -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-graph-up-arrow text-primary" style="font-size:55px;"></i>

        <div class="count text-primary">

            {{ $totalProgress }}

        </div>

        <div class="title">

            Progress Records

        </div>

    </div>

</div>

</div>

<br>

<h3 class="text-warning mb-4">

    ⚡ Quick Actions

</h3>

<div class="row">
<!-- Add Membership -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-credit-card-2-front-fill text-warning"
           style="font-size:55px;"></i>

        <h4 class="mt-3">Membership Plans</h4>

        <p class="text-secondary">
            Create, edit and manage membership plans.
        </p>

        <a href="{{ route('membership-plans.index') }}"
           class="btn btn-orange">

            Manage Plans

        </a>

    </div>

</div>


<!-- Workout Plans -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-activity text-info"
           style="font-size:55px;"></i>

        <h4 class="mt-3">Workout Plans</h4>

        <p class="text-secondary">
            Create and update workout plans.
        </p>

        <a href="{{ route('workout-plans.index') }}"
           class="btn btn-orange">

            Manage Workouts

        </a>

    </div>

</div>


<!-- Workout Videos -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-camera-video-fill text-danger"
           style="font-size:55px;"></i>

        <h4 class="mt-3">Workout Videos</h4>

        <p class="text-secondary">
            Upload and manage workout videos.
        </p>

        <a href="{{ route('workout-videos.index') }}"
           class="btn btn-orange">

            Manage Videos

        </a>

    </div>

</div>


<!-- Progress -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-graph-up-arrow text-success"
           style="font-size:55px;"></i>

        <h4 class="mt-3">Progress</h4>

        <p class="text-secondary">
            View and manage user progress.
        </p>

        <a href="{{ route('progress.index') }}"
           class="btn btn-orange">

            View Progress

        </a>

    </div>

</div>


<!-- User Dashboard -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-person-circle text-primary"
           style="font-size:55px;"></i>

        <h4 class="mt-3">User Dashboard</h4>

        <p class="text-secondary">
            Open the user dashboard.
        </p>

        <a href="{{ route('dashboard') }}"
           class="btn btn-orange">

            Open Dashboard

        </a>

    </div>

</div>


<!-- Home -->

<div class="col-lg-4 col-md-6 mb-4">

    <div class="card-box text-center">

        <i class="bi bi-house-door-fill text-warning"
           style="font-size:55px;"></i>

        <h4 class="mt-3">Website Home</h4>

        <p class="text-secondary">
            Visit the FitTrack home page.
        </p>

        <a href="{{ route('home') }}"
           class="btn btn-orange">

            Visit Home

        </a>

    </div>

</div>

</div>

<hr class="border-warning my-5">

<h3 class="text-warning mb-4">

System Overview

</h3>

<div class="alert alert-dark border border-warning">

    <h5 class="text-warning">

        FitTrack Gym Membership & Workout Management System

    </h5>

    <p class="mb-2">

        ✔ User Registration & Login

    </p>

    <p class="mb-2">

        ✔ Membership Management

    </p>

    <p class="mb-2">

        ✔ Workout Plans

    </p>

    <p class="mb-2">

        ✔ Workout Videos

    </p>

    <p class="mb-2">

        ✔ Progress Tracking (BMI)

    </p>

    <p class="mb-0">

        ✔ Admin Dashboard & Reports

    </p>

</div>
<!-- Footer -->

<footer class="mt-5">

    <div class="card-box text-center">

        <h4 class="text-warning mb-3">

            💪 FitTrack Admin Panel

        </h4>

        <p class="text-secondary">

            Gym Membership & Workout Management System

        </p>

        <hr class="border-warning">

        <div class="row text-center">

            <div class="col-md-4">

                <h5 class="text-warning">

                    Quick Links

                </h5>

                <p>
                    <a href="{{ route('membership-plans.index') }}"
                       class="text-decoration-none text-light">
                        Membership Plans
                    </a>
                </p>

                <p>
                    <a href="{{ route('workout-plans.index') }}"
                       class="text-decoration-none text-light">
                        Workout Plans
                    </a>
                </p>

                <p>
                    <a href="{{ route('workout-videos.index') }}"
                       class="text-decoration-none text-light">
                        Workout Videos
                    </a>
                </p>

            </div>

            <div class="col-md-4">

                <h5 class="text-warning">

                    Contact

                </h5>

                <p>📍 Nashik, Maharashtra</p>

                <p>📧 fittrack@gmail.com</p>

                <p>📞 +91 9876543210</p>

            </div>

            <div class="col-md-4">

                <h5 class="text-warning">

                    System

                </h5>

                <p>Laravel 12</p>

                <p>Bootstrap 5</p>

                <p>MySQL Database</p>

            </div>

        </div>

        <hr class="border-warning">

        <p class="mb-0 text-secondary">

            © 2026 FitTrack Admin Dashboard | All Rights Reserved

        </p>

    </div>

</footer>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>