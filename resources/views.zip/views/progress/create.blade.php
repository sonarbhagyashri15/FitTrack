<!DOCTYPE html>
<html>

<head>

    <title>Add Progress</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background:#0f172a;
            color:white;
        }

        .card{
            background:#1e293b;
            border:2px solid orange;
            border-radius:15px;
        }

        .btn-custom{
            background:orange;
            color:black;
            font-weight:bold;
        }

    </style>

</head>

<body>

<div class="container mt-5">

<div class="card p-4">

<h2 class="text-warning mb-4">

Add Progress

</h2>

<form action="{{ route('progress.store') }}" method="POST">

@csrf

<div class="mb-3">

<label>Weight (kg)</label>

<input type="number"
step="0.01"
name="weight"
class="form-control">

</div>

<div class="mb-3">

<label>Height (cm)</label>

<input type="number"
step="0.01"
name="height"
class="form-control">

</div>

<div class="mb-3">

<label>Date</label>

<input type="date"
name="workout_date"
class="form-control">

</div>

<button class="btn btn-custom">

Save Progress

</button>

</form>

</div>

</div>

</body>

</html>