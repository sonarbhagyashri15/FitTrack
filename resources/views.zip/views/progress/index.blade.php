<!DOCTYPE html>
<html>

<head>

<title>Progress</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-dark text-white">

<div class="container mt-5">

<h2 class="text-warning">

Progress Tracker

</h2>

<a href="{{ route('progress.create') }}"
class="btn btn-warning mb-4">

+ Add Progress

</a>

<table class="table table-dark table-bordered">

<tr>

<th>Date</th>

<th>Weight</th>

<th>Height</th>

<th>BMI</th>

</tr>

@foreach($progress as $item)

<tr>

<td>{{ $item->workout_date }}</td>

<td>{{ $item->weight }} kg</td>

<td>{{ $item->height }} cm</td>

<td>{{ $item->bmi }}</td>

</tr>

@endforeach

</table>

</div>

</body>

</html>
