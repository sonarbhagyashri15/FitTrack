<?php

namespace App\Http\Controllers;

use App\Models\Progress;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProgressController extends Controller
{
    // Show all progress records
    public function index()
    {
        $progress = Progress::where('user_id', Auth::id())
            ->latest('workout_date')
            ->get();

        return view('progress.index', compact('progress'));
    }

    // Show add progress form
    public function create()
    {
        return view('progress.create');
    }

    // Save progress
    public function store(Request $request)
    {
        $request->validate([
            'weight' => 'required|numeric|min:20|max:500',
            'height' => 'required|numeric|min:50|max:300',
            'workout_date' => 'required|date',
        ]);

        $height = $request->height / 100;
        $bmi = round($request->weight / ($height * $height), 2);

        Progress::create([
            'user_id' => Auth::id(),
            'weight' => $request->weight,
            'height' => $request->height,
            'bmi' => $bmi,
            'workout_date' => $request->workout_date,
        ]);

        return redirect()
            ->route('progress.index')
            ->with('success', 'Progress added successfully.');
    }

    // Show edit form
    public function edit($id)
    {
        $progress = Progress::where('user_id', Auth::id())
            ->findOrFail($id);

        return view('progress.edit', compact('progress'));
    }

    // Update progress
    public function update(Request $request, $id)
    {
        $request->validate([
            'weight' => 'required|numeric|min:20|max:500',
            'height' => 'required|numeric|min:50|max:300',
            'workout_date' => 'required|date',
        ]);

        $progress = Progress::where('user_id', Auth::id())
            ->findOrFail($id);

        $height = $request->height / 100;
        $bmi = round($request->weight / ($height * $height), 2);

        $progress->update([
            'weight' => $request->weight,
            'height' => $request->height,
            'bmi' => $bmi,
            'workout_date' => $request->workout_date,
        ]);

        return redirect()
            ->route('progress.index')
            ->with('success', 'Progress updated successfully.');
    }

    // Delete progress
    public function destroy($id)
    {
        $progress = Progress::where('user_id', Auth::id())
            ->findOrFail($id);

        $progress->delete();

        return redirect()
            ->route('progress.index')
            ->with('success', 'Progress deleted successfully.');
    }
}