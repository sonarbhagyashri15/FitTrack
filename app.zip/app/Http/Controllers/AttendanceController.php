<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use App\Models\User;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    /**
     * Display Attendance List
     */
    public function index()
    {
        $attendance = Attendance::with('user')
            ->latest()
            ->get();

        return view('attendance.index', compact('attendance'));
    }

    /**
     * Show Add Attendance Form
     */
    public function create()
    {
        $users = User::all();

        return view('attendance.create', compact('users'));
    }

    /**
     * Store Attendance
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'attendance_date' => 'required|date',
            'status' => 'required'
        ]);

        Attendance::create([
            'user_id' => $request->user_id,
            'attendance_date' => $request->attendance_date,
            'status' => $request->status
        ]);

        return redirect()
            ->route('attendance.index')
            ->with('success', 'Attendance Added Successfully.');
    }

    /**
     * Show Edit Form
     */
    public function edit($id)
    {
        $attendance = Attendance::findOrFail($id);
        $users = User::all();

        return view('attendance.edit', compact('attendance', 'users'));
    }

    /**
     * Update Attendance
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'user_id' => 'required',
            'attendance_date' => 'required|date',
            'status' => 'required'
        ]);

        $attendance = Attendance::findOrFail($id);

        $attendance->update([
            'user_id' => $request->user_id,
            'attendance_date' => $request->attendance_date,
            'status' => $request->status
        ]);

        return redirect()
            ->route('attendance.index')
            ->with('success', 'Attendance Updated Successfully.');
    }

    /**
     * Delete Attendance
     */
    public function destroy($id)
    {
        $attendance = Attendance::findOrFail($id);

        $attendance->delete();

        return redirect()
            ->route('attendance.index')
            ->with('success', 'Attendance Deleted Successfully.');
    }
}