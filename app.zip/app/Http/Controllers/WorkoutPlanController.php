<?php

namespace App\Http\Controllers;

use App\Models\WorkoutPlan;
use Illuminate\Http\Request;

class WorkoutPlanController extends Controller
{

    public function index()
    {
        $workouts = WorkoutPlan::all();

        return view('workout.index', compact('workouts'));
    }


    public function create()
    {
        return view('workout.create');
    }


    public function store(Request $request)
    {

        $request->validate([

            'workout_name'=>'required',
            'category'=>'required',
            'duration'=>'required',
            'description'=>'required'

        ]);


        WorkoutPlan::create([

            'workout_name'=>$request->workout_name,
            'category'=>$request->category,
            'duration'=>$request->duration,
            'description'=>$request->description

        ]);


        return redirect()
        ->route('workout-plans.index');

    }
public function edit($id)
{
    $workout = WorkoutPlan::findOrFail($id);

    return view('workout.edit', compact('workout'));
}



public function update(Request $request, $id)
{

    $request->validate([
    'workout_name' => 'required|max:100',
    'category'     => 'required|max:100',
    'duration'     => 'required|max:50',
    'description'  => 'required'
]);
    $workout = WorkoutPlan::findOrFail($id);


    $workout->update([

        'workout_name'=>$request->workout_name,
        'category'=>$request->category,
        'duration'=>$request->duration,
        'description'=>$request->description

    ]);


    return redirect()
    ->route('workout-plans.index');

}



public function destroy($id)
{

    $workout = WorkoutPlan::findOrFail($id);

    $workout->delete();


    return redirect()
    ->route('workout-plans.index');

}
}