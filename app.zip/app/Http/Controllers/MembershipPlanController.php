<?php

namespace App\Http\Controllers;

use App\Models\MembershipPlan;
use Illuminate\Http\Request;

class MembershipPlanController extends Controller
{

    public function index()
    {
        $plans = MembershipPlan::all();

        return view('membership.index', compact('plans'));
    }


    public function create()
    {
        return view('membership.create');
    }


    public function store(Request $request)
    {

        $request->validate([
            'plan_name'=>'required',
            'duration'=>'required',
            'price'=>'required',
            'description'=>'required'
        ]);


        MembershipPlan::create([

            'plan_name'=>$request->plan_name,
            'duration'=>$request->duration,
            'price'=>$request->price,
            'description'=>$request->description

        ]);


        return redirect()
        ->route('membership-plans.index');

    }



    public function edit($id)
    {
        $plan = MembershipPlan::findOrFail($id);

        return view('membership.edit', compact('plan'));
    }



    public function update(Request $request, $id)
    {

        $request->validate([
            'plan_name' => 'required|max:100',
            'duration'  => 'required|max:50',
            'price'     => 'required|numeric|min:0',
            'description' => 'required'
        ]);


        $plan = MembershipPlan::findOrFail($id);


        $plan->update([

            'plan_name'=>$request->plan_name,
            'duration'=>$request->duration,
            'price'=>$request->price,
            'description'=>$request->description

        ]);


        return redirect()
        ->route('membership-plans.index');

    }



    public function destroy($id)
    {

        $plan = MembershipPlan::findOrFail($id);

        $plan->delete();


        return redirect()
        ->route('membership-plans.index');

    }

}