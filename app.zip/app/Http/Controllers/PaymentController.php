<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use App\Models\User;
use App\Models\MembershipPlan;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    /**
     * Display Payment List
     */
    public function index()
    {
        $payments = Payment::with(['user', 'membership'])
            ->latest()
            ->get();

        return view('payment.index', compact('payments'));
    }

    /**
     * Show Add Payment Form
     */
    public function create()
    {
        $users = User::all();
        $plans = MembershipPlan::all();

        return view('payment.create', compact('users', 'plans'));
    }

    /**
     * Store Payment
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'membership_plan_id' => 'required',
            'amount' => 'required|numeric',
            'payment_method' => 'required',
            'payment_date' => 'required|date',
            'status' => 'required'
        ]);

        Payment::create([
            'user_id' => $request->user_id,
            'membership_plan_id' => $request->membership_plan_id,
            'amount' => $request->amount,
            'payment_method' => $request->payment_method,
            'payment_date' => $request->payment_date,
            'status' => $request->status,
        ]);

        return redirect()
            ->route('payments.index')
            ->with('success', 'Payment Added Successfully.');
    }

    /**
     * Show Edit Form
     */
    public function edit($id)
    {
        $payment = Payment::findOrFail($id);

        $users = User::all();
        $plans = MembershipPlan::all();

        return view('payment.edit', compact(
            'payment',
            'users',
            'plans'
        ));
    }

    /**
     * Update Payment
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'user_id' => 'required',
            'membership_plan_id' => 'required',
            'amount' => 'required|numeric',
            'payment_method' => 'required',
            'payment_date' => 'required|date',
            'status' => 'required'
        ]);

        $payment = Payment::findOrFail($id);

        $payment->update([
            'user_id' => $request->user_id,
            'membership_plan_id' => $request->membership_plan_id,
            'amount' => $request->amount,
            'payment_method' => $request->payment_method,
            'payment_date' => $request->payment_date,
            'status' => $request->status,
        ]);

        return redirect()
            ->route('payments.index')
            ->with('success', 'Payment Updated Successfully.');
    }

    /**
     * Delete Payment
     */
    public function destroy($id)
    {
        $payment = Payment::findOrFail($id);

        $payment->delete();

        return redirect()
            ->route('payments.index')
            ->with('success', 'Payment Deleted Successfully.');
    }
}